# Codex Prompt — UI + HUD
Create minimal HUD (HP, stamina, companion status). Add holographic menu skins.
