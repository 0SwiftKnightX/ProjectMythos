# Codex Prompt — GameCore
Implement a robust state machine: Boot → MainMenu → InWorld → InBattle → Pause.
Expose hooks for saving/loading and realm-layer switching. Unit-test state transitions.
