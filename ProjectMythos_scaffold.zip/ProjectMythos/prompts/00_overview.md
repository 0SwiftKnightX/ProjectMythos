# Codex Prompt — Overview
Goal: Expand the Project Mythos scaffold into a runnable prototype.
Follow file-specific prompts in numeric order. Use C++17 and keep headers lean.
