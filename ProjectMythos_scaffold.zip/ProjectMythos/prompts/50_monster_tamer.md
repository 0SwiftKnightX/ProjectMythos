# Codex Prompt — Monster Tamer
Data-drive species via JSON (traits, skills). Implement capture rituals and a basic AI companion.
