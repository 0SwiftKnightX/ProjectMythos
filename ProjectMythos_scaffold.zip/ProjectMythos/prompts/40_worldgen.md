# Codex Prompt — WorldGen
Prototype 2 biomes (AncientForest, NeonOutskirts) with simple procedural tile/prop scatter.
