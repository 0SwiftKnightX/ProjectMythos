# Codex Prompt — Android Build
Ensure Gradle+CMake builds a native binary. Verify arm64-v8a output and manifest setup.
