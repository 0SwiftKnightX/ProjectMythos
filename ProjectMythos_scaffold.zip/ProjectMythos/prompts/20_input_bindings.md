# Codex Prompt — Input Bindings
Integrate with RTDink/Proton input. Map: Move, Dodge, Jump, Light, Heavy, Interact, Summon.
Provide a cross-platform abstraction with deadzones and rebind UI stubs.
