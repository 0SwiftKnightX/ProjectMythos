# Codex Prompt — Combat System
Add stamina, poise, iframes, combo chains, and hit-stop feedback. Data-drive weapon definitions.
