# Codex Prompt — Save/Load
JSON-based save slots with checksums; store character, inventory, tamed creatures, and quests.
