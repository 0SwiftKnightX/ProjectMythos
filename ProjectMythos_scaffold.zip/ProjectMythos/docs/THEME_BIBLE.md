# THEME_BIBLE.md — Project Mythos v0.1

## Vision
**Forge worlds. Tame myths. Rewrite destiny.**

A cyber‑fantasy universe spanning: ancient ruins, neon megacities, dream realms, and simulated networks.

## Inspirations (selected)
- Warcraft 3 / Age of Mythology — heroic units + settlement systems
- Dark Souls / Elden Ring — weighty combat, world mystery
- Assassin’s Creed 3 / Black Flag — traversal, seafaring freedom
- MegaMan Battle Network — cyber sub‑worlds and tactical arenas
- Fallout — branching quests, crafting, retro‑future vibes
- Kingdom Hearts 2 — companions and combo expression
- Terraria / Q.U.I.R.K. — sandbox building and co‑op
- Digimon/Pokémon/Spectrobes — monster capture, evolution, fusion
- SAO / Destiny 2 / Xenoverse 2 / Zelda TOTK / Rocket League — online co‑op, loot, physics fun

## Aesthetic Direction
- **Palette:** Iridescent blues/violets, bioluminescent greens, silver highlights.
- **Lighting:** Dynamic day/night, auroral shadows, godrays in ruins.
- **UI:** Holographic runes × clean cyber glyphs. Minimal clutter.

## Music & Audio
- Hybrid orchestral × ambient synth. Harp, electric cello, granular pads.
- Diegetic layers in cyber realms (glitch motifs).

## Player Fantasy
Builder‑hero, wanderer, hacker‑tamer. Switch between **Reality** and **Dream Layers**, recruit mythic companions, and found settlements in hostile biomes.

## Pillars
1. **Freedom to Create** — structures, vehicles, artifacts; player‑driven goals.
2. **Adaptive Companions** — monster AI that learns from player habits.
3. **Deep Customization** — build/class hybrids, ornaments, fashion.
4. **Tactical Flow Combat** — windows, poise, synergy with companions.
5. **Co‑op Realms** — host worlds; trade, duel, build, raid.

## Mechanics Snapshot
- **Combat:** stamina + timing; light/heavy/ranged; companion synergy moves.
- **Taming:** capture rituals; traits; fusion trees; emotional bonds.
- **Crafting:** modular recipes; settlement workbenches; tech‑runes.
- **Exploration:** realm layers; environmental puzzles; traversal tools.
- **Progression:** talent constellations, gear tiers, settlement upgrades.
- **Economy:** barter + crafting currency; seasonal events.
- **Online:** opt‑in co‑op, instanced bosses, shared hubs.

## Content Production Notes
- Start with **2 biomes** (Ancient Forest, Neon Outskirts).
- **8 starter creatures**, 2 faction questlines, 1 settlement.
- Keep asset scope lean; target stylized PBR + sprites mix.
