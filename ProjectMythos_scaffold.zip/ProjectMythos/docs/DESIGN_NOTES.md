# DESIGN_NOTES.md
- Keep core loop vertical slice small (2 biomes, 1 settlement, 8 creatures).
- Prioritize moment-to-moment feel: input latency, hit-stop, readable FX.
- Early telemetrics strictly local and opt-in if later networked.
