#include "GameCore.h"

void GameCore::init() {
    loadWorld();
    player = std::make_unique<PlayerController>();
}

void GameCore::update(float deltaTime) {
    if (player) player->update(deltaTime);
    world.update(deltaTime);
}

void GameCore::loadWorld() {
    world.generate();
}
