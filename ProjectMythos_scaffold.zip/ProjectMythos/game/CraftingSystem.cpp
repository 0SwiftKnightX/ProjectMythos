#include "CraftingSystem.h"
bool CraftingSystem::craft(const std::string&) { return false; /* TODO */ }
