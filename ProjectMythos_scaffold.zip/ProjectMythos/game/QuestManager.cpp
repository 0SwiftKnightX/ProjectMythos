#include "QuestManager.h"
void QuestManager::add(const Quest& q) { quests.push_back(q); }
void QuestManager::update(float) { /* TODO: Advance quest states */ }
