#include "MonsterTamer.h"
void MonsterTamer::captureCreature(const std::string& species) { tamedCreatures.push_back(species); }
void MonsterTamer::summon(int index) { /* TODO: Spawn companion AI */ }
