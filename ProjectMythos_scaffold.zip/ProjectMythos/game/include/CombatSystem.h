#pragma once
class CombatSystem {
public:
    void update(float dt);
};
