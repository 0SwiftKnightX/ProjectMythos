#pragma once
class WorldGen {
public:
    void generate();
    void update(float dt);
};
