#pragma once
#include <memory>
#include <string>
#include "WorldGen.h"
#include "PlayerController.h"

class GameCore {
public:
    void init();
    void update(float deltaTime);
    void loadWorld();
private:
    WorldGen world;
    std::unique_ptr<PlayerController> player;
};
