#include "CombatSystem.h"
void CombatSystem::update(float) {
    // TODO: Souls-like timing windows, stamina
}
