#include "WorldGen.h"
void WorldGen::generate() {
    // TODO: Multi-biome procedural generation hooks
}
void WorldGen::update(float) {
    // TODO: Streaming & LOD
}
